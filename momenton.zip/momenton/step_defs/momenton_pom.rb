##Login Screen

def  test_app_id
  find('#ctl00_MainContent_username')
end

def  test_app_pass
  find('#ctl00_MainContent_password')
end

def  test_app_submit
  find('#ctl00_MainContent_login_button')
end

def  test_login_dets
  find(:xpath, '//*[@id="aspnetForm"]/div[3]/p[3]')
end


##Homepage

def  create_momentum_order
  #find('a[href=Process.aspx]')
  find_link('Order')
end

def  view_momentum_order
  find_link('View all orders')
end

def  delete_momentum_orderbtn
  find('#ctl00_MainContent_btnDelete')
end


##Orders page

def  test_order_product
  find('#ctl00_MainContent_fmwOrder_ddlProduct')
end

def  test_order_quantity
  find('#ctl00_MainContent_fmwOrder_txtQuantity')
end

def  test_order_calculate
  find_button('Calculate')
end

def  test_order_custname
  find('#ctl00_MainContent_fmwOrder_txtName')
end

def  test_order_street
  find('#ctl00_MainContent_fmwOrder_TextBox2')
end

def  test_order_city
  find('#ctl00_MainContent_fmwOrder_TextBox3')
end

def  test_order_state
  find('#ctl00_MainContent_fmwOrder_TextBox4')
end

def  test_order_zip
  find('#ctl00_MainContent_fmwOrder_TextBox5')
end

def  test_order_visaoptn
  find('#ctl00_MainContent_fmwOrder_cardList_0')
end

def  test_order_masteroptn
  find('#ctl00_MainContent_fmwOrder_cardList_1')
end

def  test_order_amexoptn
  find('#ctl00_MainContent_fmwOrder_cardList_2')
end

def  test_order_cardno
  find('#ctl00_MainContent_fmwOrder_TextBox6')
end

def  test_order_cardexp
  find('#ctl00_MainContent_fmwOrder_TextBox1')
end

def  test_order_process
  find('#ctl00_MainContent_fmwOrder_InsertButton')
end

def  test_order_updatebtn
  find('#ctl00_MainContent_fmwOrder_UpdateButton')
end

##Others


def  test_app_logout
  find('#ctl00_logout')
end