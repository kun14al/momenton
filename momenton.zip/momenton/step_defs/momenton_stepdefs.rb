When (/^I have opened the test url (.+)/) do |link|

  visit(link)

end

And (/^I maximize the web page/) do

  wind = Capybara.current_session.driver.browser.manage.window
  wind.resize_to(1024, 768)
  sleep 1

end


Then (/^I log into the momenton test app with credentials/) do

  uname_fld = test_login_dets.text
  puts 'User dets are : ' +uname_fld.to_s

  uname1 = uname_fld.gsub('Username - ','')
  uname2 = uname1.gsub('Password - ','')

  user_dets = uname2.split(" ")

  test_app_id.set user_dets[0]
  test_app_pass.set user_dets[1]
  test_app_submit.click

  sleep 1

end


Then (/^the momenton login should be successful/) do

  expect(page).to have_content("Welcome, Tester!")

end


Then (/^I start to create a new momenton/) do

  create_momentum_order.click

end

Then (/^I provide the new momenton order details (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+)/) do |prod_type, prod_qty, cust_name, order_street, order_city, order_state, order_zip, order_card, card_no, card_exp|

  expect(page).to have_content("Product Information")
  expect(page).to have_content("Address Information")
  expect(page).to have_content("Payment Information")

  test_order_product.select prod_type
  test_order_quantity.set prod_qty
  test_order_calculate.click

  test_order_custname.set cust_name
  test_order_street.set order_street
  test_order_city.set order_city
  test_order_state.set order_state

  case order_card

    when 'Visa'
      test_order_visaoptn.click
    when 'MasterCard'
      test_order_visaoptn.click
    when 'AmEx'
      test_order_visaoptn.click
    else
      raise 'Invalid card type provided'

  end

  test_order_zip.set order_zip
  test_order_cardno.set card_no
  test_order_cardexp.set card_exp
  test_order_process.click

  sleep 1

  expect(test_order_custname.text.to_s).to have_content ''

end


Then (/^I edit the newly created momenton order (.+), (.+), (.+)/) do |prod_qty, cust_name, upd_cust|

  find(:xpath, '//*[@id="ctl00_MainContent_orderGrid"]/tbody/tr[2]/td[13]/input').click

  sleep 1
  expect(page).to have_content("Product Information")
  expect(page).to have_content("Address Information")
  expect(page).to have_content("Payment Information")

  expect(test_order_quantity.value).to have_content prod_qty
  expect(test_order_custname.value).to have_content cust_name

  @prod_qty1 = prod_qty.to_i*2
  @cust_name1 = upd_cust

  test_order_custname.set upd_cust
  test_order_quantity.set @prod_qty1

  test_order_calculate.click

  test_order_updatebtn.click

end

And (/^I search for "(.*?)"/) do |wo_num|

  core_srch_wo_fld.set wo_num
  core_search_wo.click

end


And (/^I logout of the momenton app successfully/) do

  test_app_logout.click
  sleep 1

  expect(page).to have_content("In order to log in Orders sample use the following information:")

end


Then (/^I go to the momenton dashboard/) do

  view_momentum_order.click

end


Then (/^the newly created momenton order should be reflected there (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+)/) do |prod_type, prod_qty, cust_name, order_street, order_city, order_state, order_zip, order_card, card_no, card_exp|

  tab_row = find('#ctl00_MainContent_orderGrid').all('tr')[1].text
  puts '1st table row - ' +tab_row.to_s

  expect(tab_row).to have_content prod_type
  expect(tab_row).to have_content prod_qty
  expect(tab_row).to have_content cust_name
  expect(tab_row).to have_content order_street
  expect(tab_row).to have_content order_city
  expect(tab_row).to have_content order_state
  expect(tab_row).to have_content order_zip
  expect(tab_row).to have_content order_card
  expect(tab_row).to have_content card_no
  expect(tab_row).to have_content card_exp

end


Then (/^the edit on the momenton order should be displayed (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+), (.+)/) do |prod_type, prod_qty, cust_name, order_street, order_city, order_state, order_zip, order_card, card_no, card_exp|

  tab_row = find('#ctl00_MainContent_orderGrid').all('tr')[1].text
  puts '1st table row - ' +tab_row.to_s

  expect(tab_row).to have_content prod_type
  expect(tab_row).to_not have_content prod_qty
  expect(tab_row).to_not have_content cust_name
  expect(tab_row).to have_content order_street
  expect(tab_row).to have_content order_city
  expect(tab_row).to have_content order_state
  expect(tab_row).to have_content order_zip
  expect(tab_row).to have_content order_card
  expect(tab_row).to have_content card_no
  expect(tab_row).to have_content card_exp

  expect(tab_row).to have_content @prod_qty1
  expect(tab_row).to have_content @cust_name1

  @new_order_chkbox = find('#ctl00_MainContent_orderGrid_ctl02_OrderSelector')

end


Then (/^I delete the newly created momenton order/) do

  @new_order_chkbox.click
  delete_momentum_orderbtn.click

end


Then (/^the newly created momenton order should not be reflected on the dashboard/) do

  tab_row = find('#ctl00_MainContent_orderGrid').all('tr')[1].text
  puts '1st table row post deletion- ' +tab_row.to_s

  expect(tab_row).to_not have_content @prod_qty1
  expect(tab_row).to_not have_content @cust_name1

end
