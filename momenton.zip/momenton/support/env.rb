require 'rspec/expectations'
require 'capybara/cucumber'
require 'net/http'
require 'selenium-webdriver'
#require 'byebug'
#require 'active_support/all'

#include ActiveSupport::NumberHelper

Capybara.register_driver :chrome do |app|
  #Capybara::Selenium::Driver.new(app, :browser => :chrome, :args => ["--window-size=1600,1600"])
  Capybara::Selenium::Driver.new(app, :browser => :chrome)
  #Capybara::Selenium::Driver.new(app, :browser => :chrome, :args => ["--window-size=1400,1600" , "--incognito"])
  #Capybara::Selenium::Driver.new(app, :browser => :firefox)
  #Capybara::Selenium::Driver.new(app, :browser => :chrome, switches: ['--incognito'])
  #Capybara.current_session.driver.browser.manage.window.maximize
end

Capybara.javascript_driver = :chrome

if ENV['RUN_IN_BROWSER']

  browser = 'firefox'
  browser = 'chrome' if ENV['RUN_IN_BROWSER'] == 'chrome'


  Capybara.register_driver :selenium do |app|
    Capybara::Selenium::Driver.new(app, :browser => browser.to_sym)
  end

  AfterStep do
    sleep (ENV['PAUSE'] || 0).to_i
    pega_auth('env file')
  end

end

Capybara.default_selector = :css
#World(RSpec::Matchers)

$ui_base_url = ''

def ui_url(path)
  $ui_base_url + path
end

